// src/services/api.ts
import axios from 'axios';
import { ClientInfo, ClientStatus } from '../types/types';

const API_BASE_URL = 'http://localhost:8080/api';

export const api = {
  captureClient: (clientInfo: ClientInfo) =>
    axios.post<ClientInfo>(`${API_BASE_URL}/capture`, clientInfo),

  updateClient: (clientInfo: ClientInfo) =>
    axios.post<ClientInfo>(`${API_BASE_URL}/outreach`, clientInfo),

  qaVerify: (clientInfo: ClientInfo) =>
    axios.post<ClientInfo>(`${API_BASE_URL}/qa-verify`, clientInfo),

  approve: (clientInfo: ClientInfo) =>
    axios.post<ClientInfo>(`${API_BASE_URL}/approve`, clientInfo),

  getClient: (id: string) =>
    axios.get<ClientInfo>(`${API_BASE_URL}/client/${id}`),

  getClientsByStatus: (status: ClientStatus) =>
    axios.get<ClientInfo[]>(`${API_BASE_URL}/clients/status/${status}`),

  getAllClients: () =>
    axios.get<ClientInfo[]>(`${API_BASE_URL}/clients`)
};