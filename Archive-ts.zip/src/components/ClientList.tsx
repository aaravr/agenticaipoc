// src/components/ClientList.tsx
import React from 'react';
import {
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Chip,
  Typography
} from '@mui/material';
import { ClientInfo } from '../types/types';

interface Props {
  clients: ClientInfo[];
  onClientSelect: (client: ClientInfo) => void;
  actionLabel: string;
}

export const ClientList: React.FC<Props> = ({ clients, onClientSelect, actionLabel }) => {
  if (clients.length === 0) {
    return (
      <Paper sx={{ p: 3, textAlign: 'center' }}>
        <Typography variant="h6">No clients available</Typography>
      </Paper>
    );
  }

  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Name</TableCell>
            <TableCell>Email</TableCell>
            <TableCell>Company</TableCell>
            <TableCell>Status</TableCell>
            <TableCell>Action</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {clients.map((client) => (
            <TableRow key={client.id}>
              <TableCell>{client.name}</TableCell>
              <TableCell>{client.email}</TableCell>
              <TableCell>{client.company}</TableCell>
              <TableCell>
                <Chip
                  label={client.status}
                  color={
                    client.status === 'APPROVED' ? 'success' :
                    client.status === 'REJECTED' ? 'error' :
                    'primary'
                  }
                />
              </TableCell>
              <TableCell>
                <Button
                  variant="contained"
                  size="small"
                  onClick={() => onClientSelect(client)}
                >
                  {actionLabel}
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};