// src/pages/AnalystDashboard.tsx
import React from 'react';
import { ClientForm } from '../components/ClientForm';
import { api } from '../services/api';
import { Alert, Container } from '@mui/material';
import { ClientInfo } from '../types/types';

export const AnalystDashboard: React.FC = () => {
  const [error, setError] = React.useState<string>('');
  const [success, setSuccess] = React.useState<string>('');

  const handleSubmit = async (data: ClientInfo) => {
    try {
      const response = await api.captureClient(data);
      setSuccess('Client information captured successfully!');
      setError('');
    } catch (err) {
      setError('Failed to capture client information');
      setSuccess('');
    }
  };

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}
      <ClientForm
        onSubmit={handleSubmit}
        title="Capture Client Information"
      />
    </Container>
  );
};
