// src/pages/ApprovalDashboard.tsx
import React from 'react';
import {
  Container,
  Typography,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Alert,
  Box
} from '@mui/material';
import { ClientInfo, ClientStatus, ApprovalStatus } from '../types/types';
import { api } from '../services/api';
import { ClientList } from '../components/ClientList';

export const ApprovalDashboard: React.FC = () => {
  const [clients, setClients] = React.useState<ClientInfo[]>([]);
  const [selectedClient, setSelectedClient] = React.useState<ClientInfo | null>(null);
  const [approvalNotes, setApprovalNotes] = React.useState<string>('');
  const [error, setError] = React.useState<string>('');
  const [success, setSuccess] = React.useState<string>('');

  const loadClients = async () => {
    try {
      const response = await api.getClientsByStatus(ClientStatus.READY_FOR_APPROVAL);
      setClients(response.data);
    } catch (err) {
      setError('Failed to load clients');
    }
  };

  React.useEffect(() => {
    loadClients();
  }, []);

  const handleApproval = async (approved: boolean) => {
    if (!selectedClient) return;

    try {
      await api.approve({
        ...selectedClient,
        approvalStatus: approved ? ApprovalStatus.APPROVED : ApprovalStatus.REJECTED,
        approvalNotes
      });
      setSuccess('Approval decision completed successfully!');
      setSelectedClient(null);
      setApprovalNotes('');
      loadClients();
    } catch (err) {
      setError('Failed to complete approval decision');
    }
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4 }}>
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}
      
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Clients Ready for Approval
        </Typography>
        <ClientList
          clients={clients}
          onClientSelect={setSelectedClient}
          actionLabel="Review"
        />
      </Box>

      <Dialog
        open={!!selectedClient}
        onClose={() => setSelectedClient(null)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>Final Approval</DialogTitle>
        <DialogContent>
          {selectedClient && (
            <Box sx={{ p: 2 }}>
              <Typography variant="h6" gutterBottom>
                Client Information
              </Typography>
              <Typography><strong>Name:</strong> {selectedClient.name}</Typography>
              <Typography><strong>Email:</strong> {selectedClient.email}</Typography>
              <Typography><strong>Phone:</strong> {selectedClient.phone}</Typography>
              <Typography><strong>Company:</strong> {selectedClient.company}</Typography>
              <Typography><strong>Address:</strong> {selectedClient.address}</Typography>
              <Typography><strong>Requirements:</strong> {selectedClient.requirements}</Typography>
              <Typography><strong>QA Status:</strong> {selectedClient.qaStatus}</Typography>
              <Typography><strong>QA Notes:</strong> {selectedClient.qaNotes}</Typography>
              
              <TextField
                fullWidth
                multiline
                rows={4}
                label="Approval Notes"
                value={approvalNotes}
                onChange={(e) => setApprovalNotes(e.target.value)}
                sx={{ mt: 2 }}
              />
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => handleApproval(false)} color="error">
            Reject
          </Button>
          <Button onClick={() => handleApproval(true)} color="primary">
            Approve
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};