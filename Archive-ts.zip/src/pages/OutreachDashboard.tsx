// src/pages/OutreachDashboard.tsx
import React from 'react';
import {
  Container,
  Typography,
  Dialog,
  Alert,
  Box
} from '@mui/material';
import { ClientInfo, ClientStatus } from '../types/types';
import { api } from '../services/api';
import { ClientList } from '../components/ClientList';
import { ClientForm } from '../components/ClientForm';

export const OutreachDashboard: React.FC = () => {
  const [clients, setClients] = React.useState<ClientInfo[]>([]);
  const [selectedClient, setSelectedClient] = React.useState<ClientInfo | null>(null);
  const [error, setError] = React.useState<string>('');
  const [success, setSuccess] = React.useState<string>('');

  const loadClients = async () => {
    try {
      const response = await api.getClientsByStatus(ClientStatus.INFORMATION_GATHERING);
      setClients(response.data);
    } catch (err) {
      setError('Failed to load clients');
    }
  };

  React.useEffect(() => {
    loadClients();
  }, []);

  const handleUpdate = async (data: ClientInfo) => {
    try {
      await api.updateClient(data);
      setSuccess('Client information updated successfully!');
      setSelectedClient(null);
      loadClients();
    } catch (err) {
      setError('Failed to update client information');
    }
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4 }}>
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}

      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Clients Needing Information
        </Typography>
        <ClientList
          clients={clients}
          onClientSelect={setSelectedClient}
          actionLabel="Update Info"
        />
      </Box>

      <Dialog
        open={!!selectedClient}
        onClose={() => setSelectedClient(null)}
        maxWidth="md"
        fullWidth
      >
        {selectedClient && (
          <ClientForm
            onSubmit={handleUpdate}
            initialData={selectedClient}
            title="Update Client Information"
          />
        )}
      </Dialog>
    </Container>
  );
};