// src/App.tsx
import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Container,
  Box
} from '@mui/material';
import { AnalystDashboard } from './pages/AnalystDashboard';
import { OutreachDashboard } from './pages/OutreachDashboard';
import { QADashboard } from './pages/QADashboard';
import { ApprovalDashboard } from './pages/ApprovalDashboard';

const App: React.FC = () => {
  return (
    <BrowserRouter>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            Client Management System
          </Typography>
          <Button color="inherit" component={Link} to="/">
            Analyst
          </Button>
          <Button color="inherit" component={Link} to="/outreach">
            Outreach
          </Button>
          <Button color="inherit" component={Link} to="/qa">
            QA
          </Button>
          <Button color="inherit" component={Link} to="/approval">
            Approval
          </Button>
        </Toolbar>
      </AppBar>

      <Container sx={{ mt: 4 }}>
        <Routes>
          <Route path="/" element={<AnalystDashboard />} />
          <Route path="/outreach" element={<OutreachDashboard />} />
          <Route path="/qa" element={<QADashboard />} />
          <Route path="/approval" element={<ApprovalDashboard />} />
        </Routes>
      </Container>
    </BrowserRouter>
  );
};

export default App;