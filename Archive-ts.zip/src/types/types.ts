// src/types/types.ts
export interface ClientInfo {
  id?: string;
  name: string;
  email: string;
  phone: string;
  company: string;
  address?: string;
  requirements?: string;
  status?: ClientStatus;
  qaStatus?: QAStatus;
  approvalStatus?: ApprovalStatus;
  qaNotes?: string;
  approvalNotes?: string;
  createdAt?: string;
  updatedAt?: string;
}

export enum ClientStatus {
  NEW = 'NEW',
  INFORMATION_GATHERING = 'INFORMATION_GATHERING',
  READY_FOR_QA = 'READY_FOR_QA',
  QA_IN_PROGRESS = 'QA_IN_PROGRESS',
  READY_FOR_APPROVAL = 'READY_FOR_APPROVAL',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED'
}

export enum QAStatus {
  NOT_STARTED = 'NOT_STARTED',
  IN_PROGRESS = 'IN_PROGRESS',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED'
}

export enum ApprovalStatus {
  NOT_STARTED = 'NOT_STARTED',
  IN_PROGRESS = 'IN_PROGRESS',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED'
}