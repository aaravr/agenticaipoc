package com.raghuet.model;

public enum ApprovalStatus {
    NOT_STARTED,
    IN_PROGRESS,
    APPROVED,
    REJECTED
}