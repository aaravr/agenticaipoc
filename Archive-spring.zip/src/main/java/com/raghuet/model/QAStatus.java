package com.raghuet.model;

public enum QAStatus {
    NOT_STARTED,
    IN_PROGRESS,
    APPROVED,
    REJECTED
}