package com.raghuet;

import com.raghuet.model.ApprovalStatus;
import com.raghuet.model.ClientInfo;
import com.raghuet.model.ClientStatus;
import com.raghuet.model.QAStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ClientRepository extends JpaRepository<ClientInfo, String> {
    List<ClientInfo> findByStatus(ClientStatus status);
    List<ClientInfo> findByQaStatus(QAStatus qaStatus);
    List<ClientInfo> findByApprovalStatus(ApprovalStatus approvalStatus);
}
