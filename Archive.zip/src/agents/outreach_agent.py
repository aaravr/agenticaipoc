# src/agents/outreach_agent.py
from src.agents.base import BaseAgent
from src.models.types import AgentState, ClientStatus


class OutreachAgent(BaseAgent):
    def __init__(self):
        super().__init__("outreach_agent")

    def process(self, state: AgentState) -> AgentState:
        try:
            result = self._get_tool("update_client_info")(state.client_info)

            if "error" not in result:
                state.client_info.update(result)
                state.status = ClientStatus.READY_FOR_QA
            else:
                state.status = ClientStatus.INFORMATION_GATHERING

            state.memory.add_memory(
                self.name,
                "outreach",
                {"result": result, "status": state.status.value}
            )

        except Exception as e:
            print(f"Outreach Agent Error: {str(e)}")
            state.status = ClientStatus.INFORMATION_GATHERING

        return state