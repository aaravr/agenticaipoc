# src/agents/base.py
from typing import Any

from langchain_openai import ChatOpenAI
from src.services.mcp_tools import mcp_tools
from src.models.types import AgentState, AgentStateDict

class BaseAgent:
    def __init__(self, name: str):
        self.name = name
        self.llm = ChatOpenAI(temperature=0)
        self.tools = mcp_tools

    def _get_tool(self, name: str) -> Any:
        return self.tools[name]

    def process(self, state: AgentState) -> AgentState:
        raise NotImplementedError