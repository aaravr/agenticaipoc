# src/agents/qa_agent.py
from src.agents.base import BaseAgent
from src.models.types import AgentState, ClientStatus


class QAAgent(BaseAgent):
    def __init__(self):
        super().__init__("qa_agent")

    def process(self, state: AgentState) -> AgentState:
        try:
            qa_data = {
                **state.client_info,
                "qaStatus": "APPROVED"
            }

            result = self._get_tool("qa_verify")(qa_data)

            if "error" not in result:
                state.client_info.update(result)
                state.status = ClientStatus.READY_FOR_APPROVAL
            else:
                state.status = ClientStatus.INFORMATION_GATHERING

            state.memory.add_memory(
                self.name,
                "qa_verify",
                {"result": result, "status": state.status.value}
            )

        except Exception as e:
            print(f"QA Agent Error: {str(e)}")
            state.status = ClientStatus.INFORMATION_GATHERING

        return state