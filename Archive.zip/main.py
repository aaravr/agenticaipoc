# main.py
from src.workflow.orchestrator import WorkflowOrchestrator
import os
from dotenv import load_dotenv


def main():
    # Load environment variables
    load_dotenv()

    # Verify OpenAI API key is set
    if not os.getenv("OPENAI_API_KEY"):
        raise ValueError("OPENAI_API_KEY environment variable is not set")

    # Sample client data
    client_data = {
        "name": "John Doe",
        "email": "john@fromagenticAI.com",
        "phone": "123-456-7890",
        "company": "AI Agent Corp"
    }

    try:
        orchestrator = WorkflowOrchestrator()
        orchestrator.execute_workflow(client_data)
    except Exception as e:
        print(f"Main error: {str(e)}")


if __name__ == "__main__":
    main()