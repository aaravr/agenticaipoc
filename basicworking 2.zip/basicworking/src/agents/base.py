# src/agents/base.py
from typing import Any, Dict
from langchain_openai import ChatOpenAI
from src.services.mock_service import MockService
from src.agents.prompts import AGENT_PROMPTS
from src.models.types import AgentState, AgentStateDict

class BaseAgent:
    def __init__(self, name: str):
        self.name = name
        self.llm = ChatOpenAI(temperature=0)
        self.mock_service = MockService()
        self.prompt = AGENT_PROMPTS.get(name, "")

    def _get_tool(self, name: str) -> Any:
        # Map tool names to mock service methods
        tool_map = {
            "get_client_info": self.mock_service.get_client_info,
            "update_client_info": self.mock_service.update_client_info,
            "send_followup_email": self.mock_service.send_followup_email,
            "verify_client_info": self.mock_service.verify_client_info,
            "check_company_registration": self.mock_service.check_company_registration,
            "validate_contact_info": self.mock_service.validate_contact_info,
            "review_compliance": self.mock_service.review_compliance,
            "check_risk_assessment": self.mock_service.check_risk_assessment,
            "final_approval": self.mock_service.final_approval
        }
        return tool_map.get(name)

    def process(self, state: AgentState) -> AgentState:
        raise NotImplementedError

    def _get_llm_response(self, prompt: str, context: Dict[str, Any]) -> str:
        # Use the LLM to process the prompt with context
        response = self.llm.invoke(prompt + "\nContext: " + str(context))
        return response.content