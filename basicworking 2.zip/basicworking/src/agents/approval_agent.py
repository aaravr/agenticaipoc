# src/agents/approval_agent.py
from src.agents.base import BaseAgent
from src.models.types import AgentState, ClientStatus


class ApprovalAgent(BaseAgent):
    def __init__(self):
        super().__init__("approval_agent")

    def process(self, state: AgentState) -> AgentState:
        try:
            approval_data = {
                **state.client_info,
                "approvalStatus": "APPROVED"
            }

            result = self._get_tool("approve_client")(approval_data)

            if "error" not in result:
                state.client_info.update(result)
                state.status = ClientStatus.COMPLETED
            else:
                state.status = ClientStatus.READY_FOR_QA

            state.memory.add_memory(
                self.name,
                "approve",
                {"result": result, "status": state.status.value}
            )

        except Exception as e:
            print(f"Approval Agent Error: {str(e)}")
            state.status = ClientStatus.READY_FOR_QA

        return state